package com.lwl.studentstat.service;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;

public class StudentStatServiceTest {
	
	private StudentStatService studentStatService;
	
	@Test
	public void getAllStudentsTest() {
		studentStatService = new StudentStatServiceImpl();
		assertEquals("Junit", studentStatService.message());
		
	}

}
