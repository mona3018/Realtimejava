package com.lwl.studentstat.util;

import java.nio.file.Path;
import java.util.List;

import com.lwl.studentstat.domain.Student;

public final  class CsvReaderUtil {

		private CsvReaderUtil() {
			
		}
		
		public List<Student> loadDataFromCSV(Path path){
			return null;
		}
}
