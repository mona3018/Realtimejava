package com.lwl.studentstat.service;

import java.util.List;
import java.util.function.Predicate;

import com.lwl.studentstat.domain.Student;
import com.lwl.studentstat.dto.StudentBasicInfoDTO;

public interface StudentStatService {

		List<Student> getStudentsByQualification(String qualification);
	    int getCountBy(Predicate<Student> predicate);
	    public List<StudentBasicInfoDTO> getStudentBasicInfo();
	    
	    public String message();
		
		
}
