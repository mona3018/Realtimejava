package com.lwl.studentstat.service;

import java.util.List;
import java.util.function.Predicate;

import com.lwl.studentstat.domain.Student;
import com.lwl.studentstat.dto.StudentBasicInfoDTO;

public class StudentStatServiceImpl implements StudentStatService {

	@Override
	public List<Student> getStudentsByQualification(String qualification) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public int getCountBy(Predicate<Student> predicate) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public List<StudentBasicInfoDTO> getStudentBasicInfo() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String message() {
		// TODO Auto-generated method stub
		return "Junit";
	}

}
