package com.lwl.studentstat;

public class Manager {
	public static void main(String[] args) {
		
	
	}
}
